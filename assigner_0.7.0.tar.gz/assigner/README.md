---
output: github_document
---

# assigner <a href="https://thierrygosselin.github.io/assigner/"><img src="man/figures/logo.png" align="right" height="160" alt="assigner logo" /></a>

<!-- badges: start -->
[![Project Status: Active](https://www.repostatus.org/badges/latest/active.svg)](https://www.repostatus.org/#active)
[![R-CMD-check](https://github.com/thierrygosselin/assigner/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/thierrygosselin/assigner/actions/workflows/R-CMD-check.yaml)
<!-- badges: end -->

`assigner` provides reproducible population-assignment workflows and fast FST
estimators. It accepts genomic data prepared with
[genometranslator](https://thierrygosselin.github.io/genometranslator/) and
assumes quality control and filtering were completed first, for example with
[radr](https://thierrygosselin.github.io/radr/).

`assignment_ngs()` supports random marker sampling and FST-ranked
Training–Holdout–Leave-one-out analyses using `adegenet` or the external
command-line program `gsi_sim`.

## Installation

```r
install.packages("remotes")
remotes::install_github("thierrygosselin/assigner")
```

`gsi_sim` is optional and is not installed by the R package. Complete
installation instructions are in the
[get-started vignette](https://thierrygosselin.github.io/assigner/articles/get_started.html).
After installing it, verify the setup with:

```r
assigner::check_gsi_sim()
```

## Start here

- [Get started](https://thierrygosselin.github.io/assigner/articles/get_started.html)
- [Function reference](https://thierrygosselin.github.io/assigner/reference/index.html)
- [FST confidence intervals](https://thierrygosselin.github.io/assigner/articles/fst_confidence_intervals.html)
- [Issue tracker](https://github.com/thierrygosselin/assigner/issues)

Record the package version with `packageVersion("assigner")` and obtain the
recommended citation with `citation("assigner")`.
